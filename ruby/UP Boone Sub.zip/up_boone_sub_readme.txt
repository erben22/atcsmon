UP Iowa Area
Boone Subdivision
E Mo Valley - E Boone

You MUST use at least version 4.2.6 of ATCS Monitor with this kit

Server: atcsmidwest.gotdns.com   Port: 4871

Audio feeds:
Fort Dodge Feed: http://www.broadcastify.com/listen/feed/7725
Fonda Feed: http://www.broadcastify.com/listen/feed/13678

Current server coverage control indication (BCP) coverage for Willett-E Boone
Field indications from W Boone-E Ames when conditions are good

Some control points are at the fringe of host site reception
This will result in missed data or no data

Thanks to Brian Rammelsberg for the Mechanicsville, IA server
Thanks to Koch S&S for hosting the Mechanicsville server
Thanks to Tim Kilbride for assisting in the Mechanicsville install and for the BCP antenna
Thanks to Adam Kithcart for the Bondurant server & host site

Audio feeds compliments of two anonymous hosts and can be found on Radio Reference

Current protocols, Genisys RFL, and Genisys 202T 1200

It is highly recommended that you use the program Protocol Monitor to decode Genisys 202T 1200, Genisys RFL You MUST use Protocol Monitor to decode HP-1
When using Protocol Monitor, you use DDE as your connection to ATCS Monitor
You MUST set the correct AAR number & Zipcode in Protocol Monitor and set ATCS Monitor for DDE
Make certain that your TCP (port number) matches in both programs

For information on how to obtain Protocol Monitor please see the home page on Yahoo Groups
https://groups.yahoo.com/neo/groups/ProtocolMonitor/info

This kit includes the following:

4 .ini files (1 for server, 3 for mobile/field use, place all 4 into your main ACTS Monitor folder)
1 .lay file (place into your layout folder)
1 .mdb files (place into your mcp folder and IMPORT contents into main database)
1 up_boone_sub_layout.txt file (place into your layout folder)
1 up_boone_sub_readme.txt file (place into your notes folder)
1 UP Boone Sub.kmz file (for use with Google Earth)

To view the layout information file click the "View" tab on the ATCS Monitor tool bar and then select "layout information"

Active text is used to show/display the following: 
H: Snow melter/heaters in use
P: Power out
M: Test/Local Control
MC: Maintainer call
LO: Lamp Out
TE: CP running time/Time in Plant
CO: Control indication for "Call On" for green signal
Green arrow in front of signal is indicative of a request for signal

Send all logs, updates and corrections to me at:
squadradio@sbcglobal.net

Thanks, Mark Loewe

928/952.15625 MCP/BCP
Omaha, NE BCP 
E Mo Valley and west 
Protocol: Genisys RFL
AAR: 802, Zipcode: 68179

928/952.23125 MCP/BCP
Logan, IA BCP
Willett & Boyer
Protocol: Genisys 202T 1200
AAR: 802, Zipcode: 52751

928/952.01875 MCP/BCP
Earling, IA BCP
Haley & W Denison
Protocol: Genisys 202T 1200
AAR: 802, Zipcode: 52751

932/941.31875 MCP/BCP
Arcadia, IA BCP
Vail & Peters 
Protocol: Genisys 202T 1200
AAR: 802, Zipcode: 52751

932/941.33125 MCP/BCP
Glidden, IA BCP
E Carroll-W Jefferson
Protocol: Genisys 202T 1200
AAR: 802, Zipcode: 52751

932/941.30625 MCP/BCP 
Dana, IA BCP
W Grand Jct-Ogden
Protocol: Genisys 202T 1200
AAR: 802, Zipcode: 52751

932/941.36875 MCP/BCP
Shipley, IA BCP
W & E Boone
Jackson-E Ames (Clinton Sub)
Protocol: Genisys 202T 1200
AAR: 802, Zipcode: 52404


Revised release: 11/04/15

Changed block between W Ames & E Ames (M1) to bonded
Added rules for protocols


Revised release: 08/25/15

Changed database for W & E Boone due to codeline change by UP
Updated layout & database for Jackson, W & E Ames due to conversion to Genisys 202T 1200
Changed active text for maintenance bits to better reflect UP designations
Mnemonics for LC (local control) changed to TEST (manual) in database


Revised release: 10/10/14

Updated server name and address due to change in aggregator host location
Changed server .ini file to read "aggregator" rather than "server" to aid in self-installer
Updated layout & database for Willett & Boyer due to conversion from HP-1 to Genisys 202T 1200
Updated layout & database for Haley & W Denison due to coversion from leased line to Genisys 202T 1200
All four of the above are now part of the 52751 Zipcode polling cycle
Changed ALL station colors to white (refer to layout notes file for field montioring)


Revised release: 1/25/14

Updated server name and port number due to changes on main aggregator


Revised release: 06/27/13

Updated layout & database for W,E,N Grand Jct & W Ogden due to conversion from HP-1 to Genisys 202T 1200
W,E,N Grand Jct & W Ogden now part of the 52751 Zipcode polling cycle
Corrected switch naming issues at W & E Grand Jct and W Ogden
Changed audio feed info to Broadcastify from RadioReference


Revised release: 10/15/12

Revised layout text


Revised release: 02/18/12

Added new switches and north siding track at W & E Boone to layout and database
New BCP in Shipley now in service, protocol Genisys 202T 1200
Same polling cycle using 52751 zip code
Flipped mnemonics for switches in database and layout at: E Mo Valley
Revised Google Earth file


Revised release: 07/20/11

Added server in Mechanicsville, IA
BCP coverage Vail-W Jefferson
Revised layout and removed active text indicators in front of signals for call on indication, replaced with simple active text
IE: 1CO or 2CO or CO


Revised release: 01/30/11

Added Jackson, W & E Ames to layout
Changed active text for maintainance indication bits from symbols to 2 letter abbreviations
Added Google earth .kmz file to kit


Revised release: 01/15/10

Added decodes and MCP info for
E MO Valley
Willett & Boyer
Tweaked layout for standardization
Removed .bmp file


Revised release: 05/30/09

Added scripting for blue blocks
Added "layout notes file" 
Added .bmp file 


Revised release 03/14/09

Correct layout address/name for CP Vail


Revised release 10/05/08

Added outer approach blocks to W & E Boone.
Added outer approach blocks at w & E Grand Jct
Removed High Bridge control point
Change station names to direction first, then location


Initial release 03/07/08