BNSF Spokane Subdivision
Monitoring Kit Version 2014-11-28
November 28, 2014

COMPATIBILITY: ATCS Monitor version 4.2.6 Beta is REQUIRED for this layout.

NEWBIES: Inexperienced users should refer to the following Wiki article for setting up ATCSMon to monitor a server connection:
http://www.atcsmonwiki.org/bin/view/Main/GettingStartedOverview

- - - - - - - - - - - - - - - -

Territory Custodian:
Todd Hackett
hogger@soundrail.com

Kit Author:
Tim Christensen
t.christensen@earthlink.net

ATCSMon server covering this layout:
 - Primary: www.atcs-wa.net : 4805

### PLEASE ### Please restrict yourself to minimizing connections to this aggregator. Aggregators only have so much bandwidth and horsepower to share with many people... So please don't be a hog.

Complete coverage of the entire layout is not guaranteed.  For questions or concerns regarding server operation and/or coverage, contact the Custodian.

Current ARES Feeds are located at: 
- Glenrose (Bruce Moline), 
- Otis Orchards (Tim Christensen), 
- Sandpoint (anonymous)
- The layout is fully and reliably covered at this time.
- Many thanks to Gary Dunn for all his work and equipment donations.


Audio server for the Spokane/Hauser area is available at:
http://www.broadcastify.com/listen/feed/10541
This stream is courtesy of Tim & Gary. 

Audio server for the Sandpoint area is avaialable at:
http://www.broadcastify.com/listen/feed/12702

Many thanks to:
- Gary Dunn
- Scott Given

- - - - - - - - - - - - - - - -
2014-11-28
- change aggregator to www.atcs-wa.net:4805

- - - - - - - - - - - - - - - -
2014-10-02
- Decode changes at UP Crossing, Boyer, Colburn and Elmira for PTC compatibility upgrade.
- Station Name changes at ERIE --> ERIE ST,  SPOKANE --> SPOKANE ST
- Aggregated Server Change

- - - - - - - - - - - - - - - -
2014-07-01
- consolidate MCP decode

- - - - - - - - - - - - - - - -
20140611 Release:
- E Babb replaced by E Cheney off the end of layout on Lakeside Sub.
- Added decodes for new MCPs on Lakeside Sub also heard on aggregator.

- - - - - - - - - - - - - - - -
20130924 Release: 
- Update aggregator MCPs.
	W Empire
	E Empire
	Sunset Jct

- - - - - - - - - - - - - - - -
20130920 Release: 
- Layout slightly too wide for 1280 display... narrowed slightly.

- - - - - - - - - - - - - - - -
20130917 Release: 
- Update aggregator MCP for Marshall & Lakeside Jct
- Layout asthetic makeover

- - - - - - - - - - - - - - - -
20130526 Release: 
Layout Update by Tim Christensen
	1. UP Jct decode updated after BNSF upgrade
	2. Changed Stations to all capital letters

- - - - - - - - - - - - - - - -
20130323 Release:
Layout Update by Tim Christensen
1. UP Crossing has been corrected to indicate the correct direction of travel for UP trains. Thanks for the catch Bruce.
UP XING:
- - K16 = 1NGK
- - K17 = 1SGK
- - K22 = 1NAK
- - K23 = 2NAK (duplicates K22)
- - K24 = 1SAK
- - K25 = 2SAK (duplicates K24)
- - C17 = 1NGZ
- - C18 = 1SGZ
2. Lakeside Jct. change the mnemonics to accurately reflect the PSO fence overlay circuit. 
LAKESIDE JCT:
- - K12 = 1WAK  (was AWAK)
- - K24 = WSFK  (was WAK) (PSO fence overlay circuit, also indicates when train shunts.)
3. Updated Broadcastify Links
4. Removed unbonded scripting for Boyer... never did work reliably. 

- - - - - - - - - - - - - - - -

20120925 Release:
Layout Update by Tim Christensen
- Incorporate BNSF G.O. #34:
- - Spokane Sub was "expanded" by BNSF in January 2012 to include UP Jct to Sandpoint Jct; and the Kootenai River Sub was "reduced" to include UP Crossing to W Whitefish. The Spokane Sub layout is one half of the "pair" of layouts which now cover these subdivisions. Colburn and Elmira now reside on the Kootenai River Sub layout.  
- Incorporate BNSF G.O. #71: 
- - "Lee Street" annotation...the new name for part of the Napa Street plant. 
- - "NSI-MAIN" annotation for Erie Lo-Side to UP 'S-I'
- - "Napa Street Center" annotation for Hi-Side signals
- Manual derails at E Overlook and W Empire are replaced with text overlays.
- Visual Basic Scripting supports occupancy emulation at the following "unbonded" sidings: Boyer
- See the BNSF Spokane Sub Decode spreadsheet for decoding details.
- Route/Occupancy indications through Napa St, Havanna, Parkwater and W Hauser are improved.
- General Format to support 1280x768 standard screen.
- Use of Arial fonts, all caps, and more readable font sizes. 


